<?php $imageDir = "images/"; ?>
<?php $thumbDir = "thumbs/"; ?>


<?php $title = 'Photobooth'; ?>
<?php $currentPage = 'index'; ?>

<?php include('head.php'); ?>


<body>
   
    <div class="title">
        <h1>Amy's 21st</h1>
    </div>
    
    <div class="gallery-style">
        <a class="button light" href="index.php">View photo sets</a>
    </div>
    
    <!-- Code for viewing all images -->
    <div class="gallery_grid my-gallery">        
        <?php // Get a list of directories containing image sets
            $imageSets = glob($imageDir . '*/', GLOB_ONLYDIR);
            
            foreach ($imageSets as $setDir) {
                // Collect the images and thumbnails
                $images = glob($setDir . '*.jpg');
                $thumbs = glob($setDir . $thumbDir . '*.jpg');
                
                for ($img = 0; $img < count($images); $img++) {
                echo '<figure class="image">' .
                        '<a href="' . $images[$img] . '" data-size="3280x2464">' .
                            '<img src="' . $thumbs[$img] . '" alt="Missing image (try reloading)"/>' .
                        '</a>' .
                     '</figure>';
                }
            }
        ?>
    </div>
    
    
    <!-- If there are slow loading speeds, there's a '.min.js' version of the UI that can be used... -->
    <?php include('photoswipe-root.php'); ?>
    
    <script src="photoswipe.js"></script>
    
<!--<?php include('footer.php'); ?>-->