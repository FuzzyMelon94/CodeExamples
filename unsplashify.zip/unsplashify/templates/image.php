<?php
    $options = get_option( 'unsplashify' ); // grab options from database
    $width = $options['unsplashify_width'];
    $height = $options['unsplashify_height'];
    $tags = empty( $options['unsplashify_tags'] ) ? "" : "/?" . $options['unsplashify_tags']; // modify the tags string to add a query
    $tags = str_replace(' ', '', $tags); // remove all spaces
?>

<div class="unsplash">
    <img src="https://source.unsplash.com/random/<?php echo $width . "x" . $height . $tags ?>" alt="No image, try reloading.">
</div>