<footer>
    <div class="footer-wrapper">
        <p>Photobooth Site</p>
    </div>
</footer>
</body>
</html>