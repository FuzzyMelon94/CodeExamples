<?php 
    $options = get_option( 'unsplashify' ); // grab the options from the database
    $width = $options['unsplashify_width'];
    $height = $options['unsplashify_height'];
    $tags = $options['unsplashify_tags'];
?>

<div class="wrap">
    <h1>Unsplashify Settings</h1>
    <form method="post" action="options.php">
        <?php settings_fields( 'unsplashify_options' ); ?>
        <?php //didn't use this becuase I didn't know how to customise it... do_settings_sections( 'unsplashify_admin' ); ?>

        <table class="form-table">
            <tr valighn="top">
                <th scope="row">Image width in pixels</th>
                <td>
                <input type="text" id="unsplashify_width" name="unsplashify[unsplashify_width]" value="<?php echo $width ?>"/>
                </td>
            </tr>

            <tr valighn="top">
                <th scope="row">Image height in pixels</th>
                <td>
                <input type="text" id="unsplashify_height" name="unsplashify[unsplashify_height]" value="<?php echo $height ?>"/>
                </td>
            </tr>

            <tr valighn="top">
                <th scope="row">Tags separated by commas (e.g. "Nature, Space, Animals")</th>
                <td>
                    <input type="text" id="unsplashify_tags" name="unsplashify[unsplashify_tags]" value="<?php echo $tags ?>"/>
                </td>
            </tr>
        </table>

        <?php submit_button(); ?>
    </form>
</div>