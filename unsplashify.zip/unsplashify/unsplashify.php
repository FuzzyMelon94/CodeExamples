<?php
/**
 * Plugin Name: Unsplashify
 * Description: Adds a random picture from Unspashify to the top the page's content area. Image size and search options can be set on the settings page. The image will be randomised every time the page is loaded.
 * Version: 1.0.0
 * Author: Tom Brown
 * License: GPL-2.0+
 */


// Only run the script if it was accessed correctly
defined( 'ABSPATH' ) or exit( 'You\'re not supposed to be here...');


class Unsplashify
{
    public $pluginName;

    public function __construct ()
    {
        $this->pluginName =  plugin_basename( __FILE__ );
    }

    // Register actions and hooks
    public function register ()
    {
        if ( is_admin() )
        {
            // Add this to the admin menu
            add_action( 'admin_menu', array( $this, 'add_admin_pages' ) );
            
            // Initialise the admin options
            add_action( 'admin_init', array( $this, 'admin_options' ) );

            // Add 'settings' link to plugin page
            add_filter( "plugin_action_links_$this->pluginName", array( $this, 'settings_link' ) );
        }

        // Insert image at the top of the content
        add_filter( 'the_content', array( $this, 'display_image' ) );
    }

    // Creates a settings link below the plugin name on the plugin page
    public function settings_link ( $links )
    {
        $settings_link = '<a href="admin.php?page=unsplashify">Settings</a>';
        array_push( $links, $settings_link );
        return $links;
    }

    // Add Unsplashify to the admin menu
    public function add_admin_pages ()
    {
        add_menu_page( 'Unsplashify',
                       'Unsplashify',
                       'manage_options',
                       'unsplashify',
                       array( $this, 'admin_index' ),
                       'dashicons-format-image' );
    }
    
    // Fetch the admin file to generate HTML for the options page
    public function admin_index ()
    {
        require_once plugin_dir_path( __FILE__ ) . 'templates/options.php';
    }

    // Setup admin page options
    public function admin_options ()
    {
        register_setting(
            'unsplashify_options',
            'unsplashify',
            array( $this, 'unsplashify_sanitize' )
        );
       
        add_settings_section(
            'unsplashify_main',
            'General Settings',
            array( $this, 'unsplashify_section_text'),
            'unsplashify_admin'
        );

        add_settings_field(
            'unsplashify_width',
            'Image width',
            array( $this, 'unsplashify_width_number' ),
            'unsplashify_admin',
            'unsplashify_main'
        );

        add_settings_field(
            'unsplashify_height',
            'Image height',
            array( $this, 'unsplashify_height_number' ),
            'unsplashify_admin',
            'unsplashify_main'
        );

        add_settings_field(
            'unsplashify_tags',
            'Search tags',
            array( $this, 'unsplashify_tags_string' ),
            'unsplashify_admin',
            'unsplashify_main'
        );
    }

    // Output text for the settings section
    public function unsplashify_section_text ()
    {
        echo '<p>Settings to change the size and type of images used.</p>';
    }

    // Sanitize inputs
    public function unsplashify_sanitize ( $input )
    {
        $new_input = array();

        // Sanitize width input (number field)
        if( isset( $input['unsplashify_width'] ) )
        {
            $new_input['unsplashify_width'] = absint( $input['unsplashify_width'] );
            empty( $new_input['unsplashify_width'] ) ? "600" : $new_input['unsplashify_width']; // ensure there's a valid value
        }

        // Sanitize height input (number field)
        if( isset( $input['unsplashify_height'] ) )
        {
            $new_input['unsplashify_height'] = absint( $input['unsplashify_height'] );
            empty( $new_input['unsplashify_width'] ) ? "600" : $new_input['unsplashify_width']; // ensure there's a valid value
        }

        // Sanitize tags input (text field)
        if( isset( $input['unsplashify_tags'] ) )
        {
            $new_input['unsplashify_tags'] = sanitize_text_field( $input['unsplashify_tags'] );
        }
            
        return $new_input;
    }

    // Fetch the image file to be generate HTML for the random image
    public function display_image ( $content )
    {
        require_once plugin_dir_path( __FILE__ ) . 'templates/image.php';
        return $content;
    }
}


// Start the plugin
if (class_exists( 'Unsplashify' ) )
{
    $unsplashify = new Unsplashify();
    $unsplashify->register();
}