<div id="main-header">
    <div class="header-wrapper">
        <div class="nav-wrapper">
            <nav class="primary-nav">
                <a href="#" class="nav-link">
                    <p class="link-icon material-icons">&#xE88A;</p>
                    <p class="link-text">View All</p>
                </a>
                
                <a href="#" class="nav-link">
                    <p class="link-icon material-icons">&#xE86F;</p>
                    <p class="link-text">Groups</p>
                </a>
                
                <a href="#" class="nav-link">
                    <p class="link-icon material-icons">&#xE021;</p>
                    <p class="link-text">Games</p>
                </a>
                
                <a href="#" class="nav-link">
                    <p class="link-icon material-icons">&#xE413;</p>
                    <p class="link-text">Gallery</p>
                </a>
                
                <a href="#" class="nav-link">
                    <p class="link-icon material-icons">&#xE0D0;</p>
                    <p class="link-text">Contact</p>
                </a>
            </nav>
        </div>
    </div>
</div>