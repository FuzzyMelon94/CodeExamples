<?php $imageDir = "images/"; ?>
<?php $thumbDir = "thumbs/"; ?>


<?php $title = 'Photobooth'; ?>
<?php $currentPage = 'index'; ?>

<?php include('head.php'); ?>


<body>
   
    <div class="title">
        <h1>Amy's 21st</h1>
    </div>
    
    <div class="gallery-style">
        <a class="button light" href="view-all.php">View all photos</a>
    </div>
    
    
    <!-- Code to view images as groups of 4 as taken by the photobooth -->
    <!-- Camera generates new folder for each set of photos, website treats folders as sets -->
    <!-- Loop through folders (sets) to generate the groups of images -->
    <div class="polaroid_grid">
        <?php // Get a list of directories containing image sets
            $imageSets = glob($imageDir . '*/', GLOB_ONLYDIR);
            
            foreach ($imageSets as $setDir) {
                // Collect the images and thumbnails
                $images = glob($setDir . '*.jpg');
                $thumbs = glob($setDir . $thumbDir . '*.jpg');
                
                echo '<div class="photoset my-gallery">';
                
                for ($img = 0; $img < count($images); $img++) {
                    echo '<figure class="photo photo-0' . ($img + 1) . '">';
                        echo '<a class="image" href="' . $images[$img] . '" data-size="3280x2464">';
                            echo '<img src="' . $thumbs[$img] . '" />';
                    
                            if ($img == count($images) - 1) {
                                echo '<p>View photos</p>';
                            }
                    
                        echo '</a>';
                    echo '</figure>';
                }
                
                echo '</div>';
            }
        ?>
    </div>

    
    
    <!-- If there are slow loading speeds, there's a '.min.js' version of the UI that can be used... -->
    <?php include('photoswipe-root.php'); ?>
    
    <script src="photoswipe.js"></script>
    
<!--<?php include('footer.php'); ?>-->